# Java 2: Project - Contact App
# Work done:
-SQL table remains unchanged
## Functional requirements:
All the functional requirements are done.
## None functional requirements:
All non-functional requirements are done.
## Notes:
- vCard files are saved to the root of the project
- Code is commented
# List of group members
## DARKWA William Kofi Danso
## GYAKARI Mary Denkyiwaa
## VERHAEGHE Romain
